package com.jobportal.application.models;

public interface DB_VARIABLES {
    public static String 
    DB="buif8mprfkfyazp9pvrn",
    HOST="buif8mprfkfyazp9pvrn-mysql.services.clever-cloud.com",
    PASSWORD="BgFDUEdqxhvULYMjdWIa",
    PORT="3306",
    URI="mysql://uyna0wp8ir8ws061:BgFDUEdqxhvULYMjdWIa@buif8mprfkfyazp9pvrn-mysql.services.clever-cloud.com:3306/buif8mprfkfyazp9pvrn",
    USER="uyna0wp8ir8ws061",
    VERSION="8.0";


    // public static String 
    // DB="job_portal",
    // HOST="localhost",
    // PASSWORD="Deepika@71199",
    // PORT="3306",
    // USER="root",
    // VERSION="8.0";
    
}
