package com.jobportal.application.models;

public enum ApplicationStatus {
    ACTIVE,REVIEWED,HIRED,REJECTED
}

