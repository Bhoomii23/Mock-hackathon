package com.jobportal.application.models;

public class PortalException extends Exception {

    public PortalException(String error) {
        super(error);
    }
}
