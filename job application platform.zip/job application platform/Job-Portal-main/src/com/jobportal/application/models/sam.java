package com.jobportal.application.models;

import com.jobportal.application.App;

public class sam{

    
}